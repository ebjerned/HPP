#define G 79

void print_pyramid(int pyramidSize);
